import openai
import json
import sys

def load_json_file(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)

def save_json_file(data, filepath):
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)

def generate_infilled_json(template, prompt_data):
    system_prompt = prompt_data.get("system_prompt", "")
    user_prompt = prompt_data.get("user_prompt", "")
    data_field = prompt_data.get("data", "")
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"{user_prompt}\nData: {data_field}\nTemplate: {json.dumps(template)}"}
    ]
    
    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=messages,
        temperature=0.0
    )
    
    infilled_json_str = response.choices[0].message.content.strip()
    return json.loads(infilled_json_str)

def main():
    if len(sys.argv) < 4:
        print("Usage: python main.py <template_json_path> <prompt_json_path> <output_json_path>")
        sys.exit(1)
    
    template_path = sys.argv[1]
    prompt_path = sys.argv[2]
    output_path = sys.argv[3]

    template = load_json_file(template_path)
    prompt_data = load_json_file(prompt_path)
    
    openai_api_key = prompt_data.get("openai_api_key")
    if not openai_api_key:
        print("Error: API key missing in prompt json under 'openai_api_key'")
        sys.exit(1)
    openai.api_key = openai_api_key
    
    result = generate_infilled_json(template, prompt_data)
    save_json_file(result, output_path)
    print(f"Result saved to {output_path}")

if __name__ == '__main__':
    main()