# pdf_text_extractor.py
import PyPDF2

def pdf_extractor(pdf_path: str) -> str:
    """Extracts text from a PDF file using PyPDF2.

    Args:
        pdf_path (str): The path to the PDF file.

    Returns:
        str: The extracted text.
    """
    text = ""
    with open(pdf_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            text += page.extract_text() or ""
    return text

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python pdf_text_extractor.py path/to/pdf")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    extracted_text = pdf_extractor(pdf_path)
    print(extracted_text)