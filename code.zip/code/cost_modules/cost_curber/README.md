### USAGE

```from cost_curber import CostCurber
import openai

texts = ["Why is the sky blue?", "Explain quantum tunnelling in 2 lines"]

curber = CostCurber(model="gpt-4o-mini")  # uses baked‑in 2025‑04 pricing
for prompt in texts:
    resp = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=250,
    )
    curber.add_iteration(
        input_string=prompt,
        output_string=resp.choices[0].message.content
    )

print(f"Total est. cost: ${curber.total_cost():.6f}")
```

As a decorator:
```
@curber.track  # auto‑captures both input + output
def call_llm(prompt: str) -> str: ...
```