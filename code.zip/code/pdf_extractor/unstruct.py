import os
import json
import tqdm
from unstructured.partition.pdf import partition_pdf

def extract_pdf(path):
    """
    Function to extract text from a PDF file.
    """
    elements = partition_pdf(path)
    return "\n".join([str(el) for el in elements])

def pdf_extractor(pdf_path):
    """
    Main function that extracts pdf and calls the cohere agent.
    """
    print('Extracting...')
    pdf_text = extract_pdf(pdf_path)
    return pdf_text

def test(pdf_path):
    print(pdf_extractor(pdf_path))

if __name__=='__main__':
    test('/Users/chand/Research_Repos/Green_Policy/text policies/HF2100.pdf')