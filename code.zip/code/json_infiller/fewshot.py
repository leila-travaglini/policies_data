import json
import random
import os

def load_data(json_path):
    """Loads data from a JSON file.

    Args:
        json_path (str): The path to the JSON file.

    Returns:
        list: A list of dictionaries loaded from the JSON file,
              or None if the file is not found or is invalid.
    """
    try:
        with open(json_path, 'r') as f:
            data = json.load(f)
            if not isinstance(data, list):
                print(f"Error: JSON file {json_path} should contain a list of objects.")
                return None
            # Optional: Validate structure further if needed
            # data = [item for item in data if isinstance(item, dict) and 'text' in item and 'classification' in item]
            return data
    except FileNotFoundError:
        print(f"Error: File not found at {json_path}")
        return None
    except json.JSONDecodeError:
        print(f"Error: Could not decode JSON from {json_path}")
        return None

def sample_fewshot_examples(data, k):
    """Randomly samples k examples from the loaded data.

    Args:
        data (list): The list of data items (dictionaries).
        k (int): The number of examples to sample.

    Returns:
        list: A list containing k randomly sampled examples,
              or the entire dataset if k is larger than the dataset size or data is empty.
    """
    if not data:
        print("Warning: No data provided to sample from.")
        return []
    if not isinstance(data, list):
        print("Warning: Invalid data format provided for sampling.")
        return []
    
    actual_k = min(k, len(data))
    if k > len(data):
        print(f"Warning: Requested {k} samples, but only {len(data)} available. Sampling {actual_k}.")
        
    if actual_k == 0:
         return []
         
    return random.sample(data, actual_k)

def format_examples_for_prompt(examples):
    """Formats the sampled examples into a string for prompt inclusion.

    Args:
        examples (list): A list of example dictionaries (containing 'text' and 'classification').

    Returns:
        str: A formatted string containing the few-shot examples.
    """
    if not examples:
        return "No few-shot examples to format."

    parts = ["### Few-shot Examples:\n"]
    for i, example in enumerate(examples):
        text = example.get('text', 'N/A')
        # Ensure classification is a dict before dumping
        classification_data = example.get('classification', {})
        if not isinstance(classification_data, dict):
            classification_data = {"error": "Invalid classification format in source data"}
            
        try:
            classification_json = json.dumps(classification_data, indent=2)
        except TypeError as e:
            classification_json = json.dumps({"error": f"JSON serialization error: {e}"}, indent=2)

        parts.append(f"\n--- Example {i+1} ---")
        parts.append("Input Text:")
        parts.append(text)
        parts.append("\nOutput JSON:")
        parts.append("```json")
        parts.append(classification_json)
        parts.append("```\n")

    parts.append("### End of Few-shot Examples\n")
    return "\n".join(parts)

def get_fewshot_prompt(json_path, k):
    """Loads data, samples k examples, and returns a formatted prompt string.

    Args:
        json_path (str): Path to the JSON file containing examples.
        k (int): Number of examples to sample.

    Returns:
        str: A formatted string ready for prompt inclusion, or an empty string on error.
    """
    data = load_data(json_path)
    if data is None:
        return "" # Return empty string if loading failed

    sampled_examples = sample_fewshot_examples(data, k)
    if not sampled_examples:
         return "" # Return empty string if no examples could be sampled

    return format_examples_for_prompt(sampled_examples)

# Example usage (optional, for testing this module directly)
print(get_fewshot_prompt("./examples.json", 3))