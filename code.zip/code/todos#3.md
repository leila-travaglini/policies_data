### TODOS:

For NAICS:
* Restrict the options

Template:
* Include "unclear"

Agreement Matrix:
* Finish scoring 

Scraping:
* Iowa pdfs...

Prompt Changes:
* Give a more proactive role + Inferential

Fewshot:
* Add more samples/whole text/summaries