import pymupdf
import fitz  # PyMuPDF

def is_strikethrough(char_bbox, segments, center_tolerance=1.5):
    """
    Check if any stored strike-through segment applies for this char.
    """
    x0, y0, x1, y1 = char_bbox
    center_y = (y0 + y1) / 2
    for y_line, seg_x0, seg_x1 in segments:
        if abs(y_line - center_y) <= center_tolerance and x0 < seg_x1 and x1 > seg_x0:
            return True
    return False

def is_underline(char_bbox, segments, tolerance=8.0):
    """
    Check if any candidate underline segment applies.
    """
    x0, y0, x1, y1 = char_bbox
    baseline_y = y1
    center_y = (y0 + y1) / 2
    for y_line, seg_x0, seg_x1 in segments:
        if abs(y_line - baseline_y) <= tolerance and y_line > center_y and x0 < seg_x1 and x1 > seg_x0:
            return True
    return False

def extract_text_with_decorations(pdf_path, skip_strike=True):
    doc = pymupdf.open(pdf_path)
    html_output = ""
    
    for page in doc:
        # 1. Get all horizontal line segments (from drawings)
        horizontal_lines = []
        for d in page.get_drawings():
            for item in d["items"]:
                if item[0] == "l":
                    p1, p2 = item[1], item[2]
                    if abs(p1.y - p2.y) < 1.0:
                        y = round(p1.y, 1)
                        horizontal_lines.append((y, min(p1.x, p2.x), max(p1.x, p2.x)))
                        
        text_data = page.get_text("rawdict")
        strike_segments = []
        
        # 2. Pre-scan page text to store all strike-through segments.
        for block in text_data["blocks"]:
            if "lines" not in block:
                continue
            for line in block["lines"]:
                for span in line["spans"]:
                    for c in span["chars"]:
                        # Use a simple center_y check against all horizontal lines.
                        x0, y0, x1, y1 = c["bbox"]
                        center_y = (y0 + y1) / 2
                        for seg in horizontal_lines:
                            y_line, seg_x0, seg_x1 = seg
                            if abs(y_line - center_y) <= 2.0 and (x0 < seg_x1 and x1 > seg_x0):
                                if seg not in strike_segments:
                                    strike_segments.append(seg)
        
        # Candidate underline segments: all horizontal lines not used for strike-through.
        candidate_underline_segments = [seg for seg in horizontal_lines if seg not in strike_segments]
        
        # 3. Process text spans, applying strike-through first then underline.
        for block in text_data["blocks"]:
            if "lines" not in block:
                continue
            for line in block["lines"]:
                for span in line["spans"]:
                    decorated_text = ""
                    current_mode = None
                    for c in span["chars"]:
                        char = c["c"]
                        bbox = c["bbox"]
                        # Check strike-through using the pre-stored segments.
                        if is_strikethrough(bbox, strike_segments):
                            mode = "s"
                        # Check underline only if not struck and using candidate underline segments.
                        elif is_underline(bbox, candidate_underline_segments):
                            mode = "u"
                        else:
                            mode = None
                            
                        if mode != current_mode:
                            if current_mode and (not skip_strike or current_mode != "s"):
                                decorated_text += f"</{current_mode}>"
                            if mode and (not skip_strike or mode != "s"):
                                decorated_text += f"<{mode}>"
                            current_mode = mode
                        if skip_strike and mode == "s":
                            continue
                        decorated_text += char
                    if current_mode and (not skip_strike or current_mode != "s"):
                        decorated_text += f"</{current_mode}>"
                    html_output += decorated_text + " "
                html_output += "\n"
    return html_output

# # Example usage:
# result_html = extract_text_with_decorations("/Users/chand/Research_Repos/Green_Policy/text policies/HF462.pdf")
# print(result_html)
