from openai import OpenAI
import json
import sys
import os
from cost_curber import CostCurber
from fewshot import get_fewshot_prompt

def load_json_file(filepath):
    with open(filepath, 'r') as f:
        return json.load(f)

def save_json_file(data, filepath):
    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)

def generate_infilled_json(client, template, prompt_data, data, examples_path, k=3):
    system_prompt = prompt_data.get("system_prompt2", "")
    user_prompt_base = prompt_data.get("user_prompt", "")
    data_field = prompt_data.get("data", "")
    
    # --- Generate Few-shot Prompt --- 
    few_shot_prompt_string = get_fewshot_prompt(examples_path, k)
    if not few_shot_prompt_string:
        print("Warning: Could not generate few-shot examples. Proceeding without them.")
        # Optionally handle this case differently, e.g., exit or raise an error
    # ----------------------------------

    # Combine few-shot examples, base user prompt, NAICS, task description, and data
    user_prompt = f"{few_shot_prompt_string}\n\n{user_prompt_base}\n{NAICS}\n{task_desc}\n#### Extracted Policy Text:\n{data}"

    # Refactor the provided template into a JSON Schema
    # Here we wrap the template as the "properties" of an object.
    # json_schema = {
    #     "type": "object",
    #     "properties": template
    # }
    json_schema = template
    
    # json_schema["format"]["schema"]["additionalProperties"] = False
    # json_schema["format"]["schema"]["properties"]["policy categories"]["additionalProperties"] = False
    # json_schema["format"]["schema"]["properties"]["lobbying entities"]["additionalProperties"] = False
    # json_schema["format"]["schema"]["required"] = ["policy categories", "lobbying entities"]
    # json_schema["format"]["schema"]["properties"]["policy categories"]["required"] = ["interest group involved", "type of policy", "green energy and environment"]
    # json_schema["format"]["schema"]["properties"]["lobbying entities"]["required"] = ["interest group type", "involved in"]
    # print(json_schema["format"]["schema"]["properties"]["policy categories"]["properties"]["interest group involved"]["items"]["enum"])
    # json_schema["format"]["strict"] = True

    json_schema["format"]["strict"] = True
    json_schema["format"]["schema"]["additionalProperties"] = False
    json_schema["format"]["schema"]["properties"]["policy categories"]["additionalProperties"] = False
    json_schema["format"]["schema"]["required"] = ["policy categories"]
    json_schema["format"]["schema"]["properties"]["policy categories"]["required"] = ["NAICS categories", "Interest of Company", "Interest of Community", "type of policy", "green energy/environment", "polluting/fossil fuel"]



    # Define a function specification for structured output using the JSON Schema.
    # function_spec = {
    #     "name": "fill_template",
    #     "description": "Return a JSON object with infilled values for the given template.",
    #     "parameters": json_schema
    # }
    
    messages = [
        {"role": "system", "content": system_prompt},
        # {"role": "user", "content": f"{user_prompt}\n#### Extracted Policy Text:\n {data}"}
        {"role": "user", "content": user_prompt}
    ]
    
    response = client.responses.create(
        model="gpt-4.1",
        input=messages,
        # functions=[function_spec],
        # function_call={"name": "fill_template"},
        text=json_schema,
        temperature=0.0
    )

    
    message = response.output_text
    print(message)
    curber.add_iteration(
        input_string=str(messages),
        output_string=message
    )
    print(f"Total est. cost: ${curber.total_cost():.6f}")
    return json.loads(message)
    # if message.get("function_call"):
    #     # Extract the JSON arguments returned by the function call.
    #     arguments = message["function_call"]["arguments"]
    #     return json.loads(arguments)
    # else:
    #     # Fallback in case the model didn't return a function_call.
    #     return json.loads(message["content"].strip())
NAICS = '''
### ONLY USE THE FOLLOWING NAICS CATEGORIES
### NAICS categorization:
Electric Transmission


2211 - Electric Power Generation, Transmission and Distribution – ANY POWER GEN
	
Renewable
2212 - Natural Gas Distribution  
221111 - Hydroelectric Power Generation
221113 - Nuclear Electric Power Generation
221114 - Solar Electric Power Generation
221115 - Wind Electric Power Generation
221116 - Geothermal Electric Power Generation
221117 - Biomass Electric Power Generation
221118 - Other Electric Power Generation (e.g., tidal, wave energy)
22111 Renewables this is not an official naics but should cover when generic references to renewable utilities instead without reference to  a specific one


Polluting


Indirect pollution
11 - Agriculture, Forestry, Fishing and Hunting,
42 - Wholesale Trade,
44-45 - Retail Trade , 
336 - Transportation Equipment Manufacturing
311 - Food Manufacturing
322 - Paper Manufacturing
484 - Truck Transportation
531 - Real Estate
424 - Merchant Wholesalers (esp. Chemicals, Petroleum)
457 - Gasoline Stations and Fuel Dealers

Direct pollution


211 - Oil and Gas Extraction
212 - Mining (except Oil and Gas)
221112 Fossil Fuel Electric Power Generation,
31-33 - Manufacturing, Transportation and Warehousing, 
21 - Mining, Quarrying, and Oil and Gas 
324 - Petroleum and Coal Products Manufacturing
325 - Chemical Manufacturing
327 - Nonmetallic Mineral Product Manufacturing
331 - Primary Metal Manufacturing


	
Water 
2213 - Water, Sewage and Other Systems
'''

task_desc = '''### Description of parameters:
With respect to the policies:
1a) Interest group involved by the policy. -
Possible Values:-
* Not: No reference to/direct effects on companies/communities.
* Policy in support the interest of companies: Policies that provide financial benefits, regulatory relief, or competitive advantages to businesses. This can include tax cuts, subsidies, deregulation, or government contracts favoring industries.
* Policy against the interest of companies: Policies that impose costs, restrictions, or additional requirements on businesses, such as increased corporate taxes, stricter environmental regulations, or anti-monopoly measures.
* Policy neutral the interest of companies: Policies that do not have a direct or significant impact on business operations, costs, or competitive positioning. These could be general governance changes or administrative measures.
* Policy in support the interest of community: Policies that provide benefits, protections, or rights to individuals, such as consumer protections, social programs, funding, tax credit, labor rights, or public health initiatives.
* Policy against the interest of community: Policies that limit individual rights, impose costs on individuals, or reduce access to essential services, such as cuts to social programs, rollbacks in consumer protections, or labor market deregulation.
* Policy neutral the interest of community: Policies that do not have a clear or significant effect on individuals' rights, financial standing, or access to services.

1b) Type of policy -
Possible Values:-
* Tax increase, fee: Policies that involve changes to tax rates for companies or individuals.
* Regulation: Policies that establish new rules, standards, or compliance requirements for industries, individuals, or government agencies.
* shift in power unclear: Policies that require to operate a change in transfer authority or decision-making power.
* shift in power more local: Policies that transfer authority or decision-making power to local (cities,county,village,town) ex..
* shift in power less local: Policies that transfer authority or decision-making power away from local (cities,county,village,town) ex..
* shift in power more state: Policies that transfer authority or decision-making power to state gov
* shift in power less state: Policies that transfer authority or decision-making power away from state gov
* shift in power more political: Policies that transfer authority or decision-making power to politicians. 
* shift in power less political: Policies that transfer authority or decision-making away from politicians
* shift in power less agencies-bureucracy: Policies that transfer authority or decision-making power away from agencies-bureucracy
* shift in power more agencies-bureucracy: Policies that transfer authority or decision-making power to agencies-bureucracy
* Subsidy, tax credit, program or funding: Policies that provide financial incentives or direct government funding to specific industries, projects, or groups.
* Definition or study: Policies that clarify legal or regulatory definitions, set new standards, or reinterpret existing rules or requiring a study.
* Logistics (boards, council,  and other appointments): Policies that relate to the creation, dissolution, or restructuring of regulatory agencies, advisory boards, or government appointments.

1c) Pro/against green energy and environment:
* Policy supporting green energy or environment:
Increase in tax bonuses, tax credits, regulations supporting, or subsidies for green energy, renewable energy, and environmental initiatives. This includes policies promoting solar, wind, hydro, geothermal, biofuels, electric vehicles, and other sustainable technologies, as well as conservation efforts for water, wildlife, forests, and land. It also covers a decrease in taxes or the removal of regulations that hinder such initiatives.

The scope includes policies related to:

Animals - Protection, conservation, or welfare policies related to wildlife and domestic animals.
Environment - General policies promoting environmental sustainability and protection.
Forests - Afforestation, deforestation prevention, and sustainable forestry policies.
Health - Environmental health policies related to pollution, toxins, and their impact on human health.
Land - Conservation, land use planning, and policies related to sustainable land management.
Natural Disaster Relief - Funding and support for recovery efforts after natural disasters.
Natural Disaster Prevention - Policies aimed at reducing the impact of future natural disasters.
Natural Resources - Conservation and sustainable use of natural resources, such as water, minerals, and biodiversity.
Renewable Energy - General policies promoting renewable energy adoption and innovation.
Solar - Incentives and regulations supporting the development and deployment of solar energy.
Wind - Policies promoting wind energy, including offshore and onshore wind farms.
Hydropower - Development, regulation, or subsidies for hydroelectric power generation.
Geothermal - Policies supporting geothermal energy development and research.
Biofuels - Incentives for biofuel production, including ethanol and biodiesel.
Electric Vehicles (EVs) - Subsidies, tax credits, and infrastructure support for EV adoption.
Water - Conservation, clean water access, and pollution control measures related to water bodies.

* Policy Opposing Green Energy or Environment:
Decrease in tax bonuses, tax credits, subsidies, or supportive regulations for green energy, renewable energy, and environmental initiatives. This includes policies that reduce financial incentives or impose restrictions on solar, wind, hydro, geothermal, biofuels, electric vehicles, and other sustainable technologies. It also covers increased taxation or new regulations that hinder environmental protection, conservation efforts, and sustainable practices.

The scope includes policies related to:

Animals - Reduction in protections, funding cuts for conservation programs, or policies that negatively impact wildlife.
Environment - Rollback of environmental protections, reduced sustainability initiatives.
Forests - Policies allowing increased deforestation, reduced funding for forest conservation.
Health - Weakening of environmental health regulations, increased exposure to harmful pollutants.
Land - Policies that promote unsustainable land use, reduce conservation efforts.
Natural Disaster Relief - Reduction in disaster recovery funding or support programs.
Natural Disaster Prevention - Cuts to programs aimed at mitigating natural disaster impacts.
Natural Resources - Deregulation or increased extraction of natural resources without sustainability measures.
Water - Reduction in clean water initiatives, deregulation of water pollution controls.
Renewable Energy - Decreased support for renewable energy investments, new restrictions on adoption.
Solar - Reduction of subsidies, tax credits, or incentives for solar power.
Wind - Restrictions on wind energy projects, removal of financial support.
Hydropower - Increased regulatory barriers for hydropower development.
Geothermal - Reduced funding or incentives for geothermal energy research and deployment.
Biofuels - Cuts to subsidies or incentives for biofuel production and adoption.
Electric Vehicles (EVs) - Reduction in EV incentives, removal of infrastructure development support.

* Policy supporting fossil fuel and related effects: 
increase in tax bonus, tax credit, subsidies, regulations supporting oil, fossil fuel, gas, toxic, plastic, water, wildlife, etc. or decrease in tax or regulation blocking.
The scope includes policies related to:
Plastic - Removal of restrictions on plastic use, reduction in bans or fees on single-use plastics.
Pollutants - Weakening of air, water, and soil pollution controls, increased emission allowances.
Recycle - Cuts to recycling programs, removal of incentives for waste reduction initiatives.
Waste - Policies that promote landfill use over sustainable waste management solutions.
Pesticide - Expansion of pesticide use allowances, rollback of safety regulations.
Chemical - Loosening of regulations on hazardous chemicals, increased permissible pollution levels.

* Policy Opposing Fossil Fuel and Related Effects: Policies that reduce financial incentives, weaken regulations, or remove subsidies that support fossil fuels, pollution-intensive industries, and related sectors. These policies may include tax increases, stricter environmental standards, phase-outs of subsidies, and limitations on fossil fuel extraction, production, and use.
The scope includes policies related to:
Tax Bonus & Tax Credit Reduction - Decrease or removal of tax incentives for fossil fuel industries, including oil, gas, coal, and petrochemicals.
Subsidy Reduction - Elimination or reduction of government subsidies for fossil fuel production, transportation, refining, or consumption.
Regulatory Rollback - Loosening or removal of environmental restrictions on fossil fuel extraction, emissions, and pollution control.
Oil & Gas - Policies phasing out tax benefits or subsidies for oil and gas exploration, drilling, refining, and distribution.
Coal - Reduction in financial or regulatory support for coal mining, processing, and power generation.
Chemical - Weakening of regulations or financial support for fossil fuel-based chemicals, including petrochemicals and fertilizers.
CO2 & Emissions - Policies that reduce or remove financial incentives for carbon-intensive industries or delay emission reduction goals.
Plastic - Reduction in government incentives or regulations supporting fossil fuel-derived plastics and plastic waste management.
Pollutants - Loosening restrictions on industrial emissions, air and water pollutants, or hazardous waste linked to fossil fuel production.
Waste & Recycling - Reduction of financial or regulatory support for programs aimed at mitigating fossil fuel-related waste, such as recycling or hazardous waste disposal.
Pesticide - Policies removing financial incentives for regulating fossil fuel-derived pesticides and agricultural chemicals.

* The scope includes policies related to:
Chemical - Regulations on hazardous chemicals, pollution control, and chemical safety measures.
Plastic - Reduction, regulation, or alternatives to plastic use and waste management.
Pollutants - Policies addressing air, water, and soil pollution, including emissions regulations.
Recycle - Promotion of recycling programs and circular economy initiatives.
Waste - Waste management policies, including reduction, disposal, and treatment of waste.
Pesticide - Regulations, bans, or subsidies related to pesticide use and its environmental impact.


* Policies with unclear effect on green energy or environment: 
Policies that involve administrative, structural, or procedural changes related to green energy, environmental regulation, or sustainability without a clear direct impact on promoting or opposing these initiatives. These policies may include governance decisions, regulatory framework adjustments, agency restructuring, or changes in oversight authority that could influence green energy and environmental policies but do not explicitly support or hinder them.
The scope includes policies related to:
Board - Establishment, modification, or dissolution of governing bodies overseeing green energy or environmental policies.
Power Transfer - Changes in jurisdiction, authority, or decision-making power over environmental or energy-related policies between agencies, departments, or levels of government.
Definition - Revisions or clarifications of legal, regulatory, or technical definitions related to green energy, pollutants, sustainability, or environmental impact assessments.
Green Energy - Structural changes that affect renewable energy policies without directly increasing or decreasing support.
Solar - Adjustments in regulatory oversight for solar projects without altering financial incentives.
Wind - Reallocation of authority over wind energy development without clear policy direction.
Hydropower - Changes in governance affecting hydroelectric projects without explicit promotion or restriction.
Geothermal - Policy shifts in geothermal energy regulation that do not directly impact deployment.
Biofuels - Revisions in standards or reporting requirements that do not affect biofuel adoption incentives.
Electric Vehicles (EVs) - Organizational or regulatory changes that impact EV policy administration without altering financial or legal support.
Water - Transfers of water conservation oversight or administrative restructuring of water management policies.
Wildlife - Changes in governance related to wildlife conservation that do not specify stronger or weaker protections.
Forests - Modifications in forest management structures without clear conservation or deforestation implications.
Natural Resources - Adjustments in resource management frameworks that do not directly impact sustainability.
Natural Disaster Prevention/Relief - Organizational restructuring of disaster response or mitigation agencies without clear effects on environmental sustainability.

* Policies with unclear effect on fossil fuel: Policies that involve administrative, structural, or procedural changes related to fossil fuels, chemicals, emissions, and related industries without a clear direct impact on promoting or opposing their use. These policies may include governance decisions, regulatory framework adjustments, agency restructuring, or shifts in oversight authority that could influence fossil fuel policy but do not explicitly support or hinder it.
The scope includes policies related to:
Board - Establishment, modification, or dissolution of governing bodies overseeing fossil fuel and chemical regulations.
Power Transfer - Changes in jurisdiction, authority, or decision-making power over fossil fuel-related policies between agencies, departments, or levels of government.
Definition - Revisions or clarifications of legal, regulatory, or technical definitions related to fossil fuels, CO₂ emissions, chemicals, and industrial pollutants.
Energy - Structural changes affecting fossil fuel energy policies without directly increasing or decreasing support.
Oil & Gas - Adjustments in regulatory oversight for oil and gas extraction, transportation, or refining without altering financial incentives.
Coal - Changes in governance affecting coal mining or coal-fired power plants without explicit policy direction.
Chemical - Modifications in regulatory structures overseeing the chemical industry without clear implications for fossil fuel use.
CO₂ - Adjustments in emissions monitoring, reporting, or administrative structures without setting new limits or financial incentives.
Pollutants - Changes in regulatory authority over emissions and pollution control without setting new limits or standards.
Recycle - Modifications in waste management administration without increasing or decreasing recycling incentives.
Waste - Policy changes regarding waste disposal oversight without clear sustainability impacts.
Plastic - Adjustments in plastic regulation enforcement without altering bans, fees, or restrictions.
Pesticide - Changes in jurisdiction over pesticide regulations without setting new usage limits.


'''


curber = CostCurber(model="gpt-4o")
def main():
    if len(sys.argv) < 6:
        print("Usage: python json_schema_mode.py <template_json_path> <prompt_json_path> <data_path> <output_json_path> <examples_json_path>")
        sys.exit(1)
    
    template_path = sys.argv[1]
    prompt_path = sys.argv[2]
    data_path = sys.argv[3]
    output_path = sys.argv[4]
    examples_path = sys.argv[5]

    template = load_json_file(template_path)
    prompt_data = load_json_file(prompt_path)
    data = load_json_file(data_path)
    # data = data[list(data.keys())[1]]
    # data = data["121"]


    
    openai_api_key = prompt_data.get("openai_api_key")

    if not openai_api_key:
        print("Error: API key missing in prompt json under 'openai_api_key'")
        sys.exit(1)

    os.environ["OPENAI_API_KEY"] = openai_api_key
    client = OpenAI()
    
    for policy in list(data.keys()):
        print(policy)
        result = generate_infilled_json(client, template, prompt_data, data[policy], examples_path)
        save_json_file(result, output_path+'_'+policy+".json")
        print(f"Result saved to {output_path+'_'+policy+".json"}")

if __name__ == '__main__':
    main()
    print(f"Total est. cost: ${curber.total_cost():.6f}")

# python json_schema_mode.py /Users/chand/Research_Repos/Green_Policy/json_infiller/template3copy.json /Users/chand/Research_Repos/Green_Policy/json_infiller/prompt.json /Users/chand/Research_Repos/Green_Policy/json_infiller/data_2.json /Users/chand/Research_Repos/Green_Policy/output_data/gpt_4.1/out_2 /Users/chand/Research_Repos/Green_Policy/json_infiller/examples.json