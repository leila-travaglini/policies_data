import json
import os
from tqdm import tqdm
from pdf_extractor.strike import extract_text_with_decorations
# from pdf_extractor.pipdf import pdf_extractor as pdf_extractor_pi
# from pdf_extractor.unstruct import pdf_extractor

def extract(pdf_path: str, extractor='pypdf'):
    # if extractor == 'unstruct':
    #     return pdf_extractor(pdf_path)
    # elif extractor == 'pypdf':
    #     return pdf_extractor_pi(pdf_path)
    if extractor == 'strike':
        return extract_text_with_decorations(pdf_path, skip_strike=True)

def jsonify(text: str, name: str):
    return json.dumps({name: text})

def get_pdf_paths(folders: list) -> list:
    """Traverse folders and return a list of paths to PDF files."""
    pdf_paths = []
    for folder in folders:
        for root, _, files in os.walk(folder):
            for file in files:
                if file.lower().endswith('.pdf'):
                    pdf_paths.append(os.path.join(root, file))
    return pdf_paths

def extract_pdfs(paths: list, fetch_paths=False, revert=True):
    json_results = []
    if fetch_paths:
        # If fetch_paths is True, treat paths as folder paths and fetch PDF file paths.
        paths = get_pdf_paths(paths)
    for i in tqdm(paths):
        name = os.path.splitext(os.path.basename(i))[0]
        text = extract(i, extractor='strike')

        # if revert and text.count('\n') > 15:
        #     print('Found many new lines...\nReverting to unstruct.io')
        #     text = extract(i, extractor='strike')
        json_results.append(jsonify(text, name))
    return json_results

def collate_jsons(json_list: list, output_file: str) -> None:
    """Collates a list of JSON strings into a single-level JSON dict and saves it to the output file."""
    combined = {}
    for js in json_list:
        data = json.loads(js)
        combined.update(data)
    with open(output_file, 'w') as f:
        json.dump(combined, f)
    print(f"Combined JSON saved to {output_file}")

if __name__=="__main__":
    paths = [
        "/Users/chand/Downloads/policies_manual/"
    ]
    # Set fetch_paths=True to fetch PDF paths from provided folders.
    results = extract_pdfs(paths, fetch_paths=True)
    collate_jsons(results, "./json_infiller/data_2.json")