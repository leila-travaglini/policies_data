# JSON Schema Infill Repo

## Overview
This repo takes a JSON template with empty values and a prompt JSON containing system/user prompts and data. It uses the OpenAI API to infill the template and saves the output.

## Usage
```bash
python main.py template.json prompt.json output.json