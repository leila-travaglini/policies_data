"""
Light‑weight loop‑aware OpenAI cost estimator.

* Counts tokens with `tiktoken`
* Keeps running totals for input/output
* Uses Decimal for money‑safe arithmetic
"""
from __future__ import annotations
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional, Iterable, Callable, Any
import tiktoken

# ---- Pricing table ---------------------------------------------------------
# Format: model -> (usd_per_1k_input_tokens, usd_per_1k_output_tokens)
_MODEL_PRICING: dict[str, tuple[Decimal, Decimal]] = {
    # April 22 2025 prices – see https://openai.com/api/pricing
    # gpt‑4o‑mini numbers confirmed by April 14 launch post & Reuters piece
    "gpt-4o-mini": (Decimal("0.00015"), Decimal("0.00060")),
    "gpt-4o":      (Decimal("0.01000"), Decimal("0.03000")),
    # new 4.1 mini variant
    "gpt-4.1-mini": (Decimal("0.00012"), Decimal("0.00048")),
    # add others as needed…
}

# ---------------------------------------------------------------------------

class CostCurber:
    def __init__(
        self,
        model: str = "gpt-4o-mini",
        pricing: Optional[dict[str, tuple[Decimal, Decimal]]] = None,
    ) -> None:
        self.model = model
        self.pricing = pricing or _MODEL_PRICING
        if model not in self.pricing:
            raise ValueError(f"Unknown model '{model}'. "
                             "Add it to your pricing table.")
        self.enc = tiktoken.encoding_for_model("gpt-4o")
        self._in_tokens = 0
        self._out_tokens = 0

    # --------‑‑ helper methods ---------------------------------------------
    def _tok(self, text: str | list[int]) -> int:
        return len(self.enc.encode(text)) if isinstance(text, str) else len(text)

    def add_iteration(
        self,
        input_string: str,
        *,
        output_string: Optional[str] = None,
        output_string_estimate: Optional[int] = None,
    ) -> None:
        """Record one round‑trip of the LLM."""
        self._in_tokens += self._tok(input_string)
        if output_string is not None:
            self._out_tokens += self._tok(output_string)
        elif output_string_estimate is not None:
            self._out_tokens += int(output_string_estimate)
        else:
            raise ValueError(
                "Provide either output_string or output_string_estimate."
            )

    # public read‑only props
    @property
    def input_tokens(self) -> int:  return self._in_tokens
    @property
    def output_tokens(self) -> int: return self._out_tokens

    def total_cost(self) -> Decimal:
        in_rate, out_rate = self.pricing[self.model]
        cost_in  = (Decimal(self._in_tokens)  / 1000) * in_rate
        cost_out = (Decimal(self._out_tokens) / 1000) * out_rate
        return (cost_in + cost_out).quantize(Decimal("0.000001"),
                                             rounding=ROUND_HALF_UP)

    # --------‑‑ optional syntactic sugar -----------------------------------
    def track(self, fn: Callable[..., str]):
        """Decorator: auto‑tracks `fn(prompt)->str` style call."""
        def wrapper(prompt: str, *a, **kw):
            output = fn(prompt, *a, **kw)
            self.add_iteration(prompt, output_string=output)
            return output
        return wrapper

    def loop(
        self,
        iterable: Iterable[Any],
        call_fn: Callable[[Any], tuple[str, str | int]],
    ) -> Decimal:
        """Straight‑through helper for stranger loops."""
        for item in iterable:
            prompt, output = call_fn(item)
            if isinstance(output, int):
                self.add_iteration(prompt, output_string_estimate=output)
            else:
                self.add_iteration(prompt, output_string=output)
        return self.total_cost()
