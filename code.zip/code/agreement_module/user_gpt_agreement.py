import pandas as pd
import json
import os

# === Configuration ===
HUMAN_CLASS_PATH = "/Users/chand/Research_Repos/Green_Policy/bill_scraper/random 1-50 policies - ian classify.xlsx"
BILL_CLASS_PATH = "/Users/chand/Research_Repos/Green_Policy/bill_scraper/random 1-50 policies - ian classify.xlsx"
GPT_JSON_FOLDER = "/Users/chand/Research_Repos/Green_Policy/agreement_module/output_data_1"

# === Subgroup Mappings ===
NAICS_SUBGROUPS = {
    "Electric Transmission": {"2211"},
    "Renewable": {"22111", "221111", "221113", "221114", "221115", "221116", "221117", "221118"},
    "Polluting - Indirect": {"11", "42", "44–45", "336", "311", "322", "484", "531", "424"},
    "Polluting - Direct": {"211", "212", "221112", "31–33", "21", "324", "325", "327", "331"},
    "Water": {"2213"},
}

# === Utility Functions ===
def normalize_naics(code):
    if not isinstance(code, str): return None
    return code.strip().split(" – ")[0].split("—")[0].strip()
    # print(code)
    # print(code.strip().split(" - ")[0].split("—")[0].strip())
    # return code.strip().split(" - ")[0].split("—")[0].strip()

def map_to_subgroup(code):
    norm = normalize_naics(code)
    for group, codes in NAICS_SUBGROUPS.items():
        if norm in codes:
            return group
    return None

def normalize_value(value_raw):
    """Normalizes a value to one of: support, against, not, neutral, unclear."""
    if pd.isna(value_raw) or not isinstance(value_raw, str) or not value_raw.strip():
        return "unclear"

    val = value_raw.lower().strip()
    print(val)
    # GPT specific phrases (and general company/community interest)
    if "in support of companies" == val or "in support of communities" == val: return "support"
    if "against companies" == val or "against communities" == val: return "against" # Assuming this phrase if it exists
    if "neutral towards companies" == val or "neutral towards communities" == val: return "neutral"

    # General terms
    if val in ["support", "supporting", "pro", "for"]: return "support"
    if val in ["against", "oppose", "con", "anti"]: return "against"
    if val in ["not", "not applicable", "none"]: return "not"
    if val in ["neutral"]: return "neutral"
    if val in ["unclear", "unknown", "ambiguous"]: return "unclear"
    
    # If after all checks, it's still not one of the above, classify as unclear.
    # This handles cases where a value might be something unexpected.
    if val not in ["support", "against", "not", "neutral", "unclear"]:
        # print(f"Warning: Value '{value_raw}' normalized to 'unclear' due to no specific mapping.")
        return "unclear"
    return val

def normalize_policy_type(policy_val_raw):
    """Normalizes a single policy type value. Lowercase and strip."""
    if not isinstance(policy_val_raw, str) or not policy_val_raw.strip():
        return None # Or some default like "unclear_policy_type"
    return policy_val_raw.lower().strip()

def get_normalized_policy_set(policy_data_raw, is_human_data=False):
    """Returns a set of normalized policy types from raw data (string or list)."""
    # If policy_data_raw is a list, let the list processing logic handle it (even if empty).
    # Otherwise, if it's a scalar None/NaN, return an empty set.
    # This avoids calling pd.isna() on a list, which causes the ValueError.
    if not isinstance(policy_data_raw, list) and pd.isna(policy_data_raw):
        return set()
    
    policies = set()
    if is_human_data and isinstance(policy_data_raw, str):
        # Human data might be a single string or semicolon-separated
        for p_val in policy_data_raw.split(';'):
            norm_p = normalize_policy_type(p_val)
            if norm_p: policies.add(norm_p)
    elif isinstance(policy_data_raw, list): # GPT data is a list
        for p_val in policy_data_raw:
            norm_p = normalize_policy_type(p_val)
            if norm_p: policies.add(norm_p)
    elif isinstance(policy_data_raw, str): # Single string entry not caught by human_data semicolon split
        norm_p = normalize_policy_type(policy_data_raw)
        if norm_p: policies.add(norm_p)
        
    return policies

def calculate_agreement_score(human_raw, gpt_raw):
    """Calculates agreement score based on normalized human and GPT values."""
    human = normalize_value(human_raw)
    gpt = normalize_value(gpt_raw)

    # Map "neutral" to "unclear" for scoring logic as per user rules focusing on support/against/not/unclear
    h = "unclear" if human == "neutral" else human
    g = "unclear" if gpt == "neutral" else gpt
    
    # SCORING:
    # same entry null vs null / against vs against/ support vs support/ unclear vs unclear = 1 point
    if h == g:
        return 1
    
    # GPT: not vs Human: unclear = 0 point (and symmetric)
    if (g == "not" and h == "unclear") or (h == "not" and g == "unclear"):
        return 0
        
    # GPT: not/unclear vs Human: support/against = -1 (and symmetric)
    if (g in ["not", "unclear"] and h in ["support", "against"]) or \
       (h in ["not", "unclear"] and g in ["support", "against"]):
        return -1
        
    # GPT: support or against vs Human against vs support = -2 
    if g in ["support", "against"] and h in ["support", "against"] and g != h:
        return -2
        
    # Fallback for any unhandled specific combinations after normalization (should be rare)
    return 0 # Default score if no rules match, though normalization aims to prevent this.

# === Load Excel Files ===
human_df = pd.read_excel(HUMAN_CLASS_PATH, sheet_name="list")
bill_df = pd.read_excel(BILL_CLASS_PATH, sheet_name="policies")

# === Process and Compare ===
records = []

for _, row in bill_df.iterrows():
    print(row["bill_number"])
    bill = row["bill_number"]
    naics_human = [normalize_naics(row[f"NAICS{i}"]) for i in range(1, 4) if pd.notnull(row.get(f"NAICS{i}"))]
    subgroups_human = {map_to_subgroup(n) for n in naics_human if map_to_subgroup(n)}

    # Human labels
    env_human_raw = row.get("EnvEn", "Unclear")
    fos_human_raw = row.get("PolFos", "Unclear")
    comp_human_raw = row.get("Company", "Unclear")
    comm_human_raw = row.get("Community", "Unclear")
    # Aggregate Type1, Type2, Type3 for human policy type
    policy_type_human_raw = [row.get("Type1", ""), row.get("Type2", ""), row.get("Type3", "")]

    # Load GPT JSON
    # Find the correct JSON file for the bill, since the file name contains the bill number uniquely
    json_path = None
    for fname in os.listdir(GPT_JSON_FOLDER):
        if f"{bill}" in fname and fname.endswith(".json"):
            json_path = os.path.join(GPT_JSON_FOLDER, fname)
            break
    if not json_path or not os.path.exists(json_path):
        continue
    with open(json_path) as f:
        gpt = json.load(f)

    gpt_naics_raw = gpt.get("policy categories", {}).get("NAICS categories") or []
    print(gpt_naics_raw)
    gpt_naics = [normalize_naics(code) for code in gpt_naics_raw]
    subgroups_gpt = {map_to_subgroup(n) for n in gpt_naics if map_to_subgroup(n)}
    print(subgroups_gpt)
    print(subgroups_human)
    # Agreement Scores
    naics_match = int(bool(subgroups_human & subgroups_gpt))
    
    env_gpt_raw = gpt.get("policy categories", {}).get("green energy/environment", "Unclear")
    fos_gpt_raw = gpt.get("policy categories", {}).get("polluting/fossil fuel", "Unclear")
    
    gpt_comp_list = gpt.get("policy categories", {}).get("Interest of Company", [])
    comp_gpt_raw = gpt_comp_list[0] if gpt_comp_list else "Unclear"
    
    gpt_comm_list = gpt.get("policy categories", {}).get("Interest of Community", [])
    comm_gpt_raw = gpt_comm_list[0] if gpt_comm_list else "Unclear"

    # Policy Types from GPT
    gpt_policy_types_raw = gpt.get("policy categories", {}).get("type of policy", [])

    # Normalize values for matrix and scoring
    env_human_norm = normalize_value(env_human_raw)
    env_gpt_norm = normalize_value(env_gpt_raw)
    fos_human_norm = normalize_value(fos_human_raw)
    fos_gpt_norm = normalize_value(fos_gpt_raw)
    comp_human_norm = normalize_value(comp_human_raw)
    comp_gpt_norm = normalize_value(comp_gpt_raw)
    comm_human_norm = normalize_value(comm_human_raw)
    comm_gpt_norm = normalize_value(comm_gpt_raw)

    # Normalize policy types
    policy_types_human_set = get_normalized_policy_set(policy_type_human_raw, is_human_data=True)
    policy_types_gpt_set = get_normalized_policy_set(gpt_policy_types_raw)

    env_score = calculate_agreement_score(env_human_raw, env_gpt_raw)
    fos_score = calculate_agreement_score(fos_human_raw, fos_gpt_raw)
    comp_score = calculate_agreement_score(comp_human_raw, comp_gpt_raw)
    comm_score = calculate_agreement_score(comm_human_raw, comm_gpt_raw)
    
    # Policy Type Intersection Score
    policy_type_intersection_score = 1 if policy_types_human_set & policy_types_gpt_set else 0

    records.append({
        "bill": bill,
        "NAICS Match": naics_match,
        "Subgroups (Human)": ", ".join(sorted(subgroups_human)) if subgroups_human else "",
        "Subgroups (GPT)": ", ".join(sorted(subgroups_gpt)) if subgroups_gpt else "",
        "Env (Human)": env_human_norm,
        "Env (GPT)": env_gpt_norm,
        "Env Score": env_score,
        "Fossil (Human)": fos_human_norm,
        "Fossil (GPT)": fos_gpt_norm,
        "Fossil Score": fos_score,
        "Company (Human)": comp_human_norm,
        "Company (GPT)": comp_gpt_norm,
        "Company Score": comp_score,
        "Community (Human)": comm_human_norm,
        "Community (GPT)": comm_gpt_norm,
        "Community Score": comm_score,
        "Policy Type (Human)": ", ".join(sorted(list(policy_types_human_set))) if policy_types_human_set else "",
        "Policy Type (GPT)": ", ".join(sorted(list(policy_types_gpt_set))) if policy_types_gpt_set else "",
        "Policy Type Intersection Score": policy_type_intersection_score,
    })

# === Output ===
df = pd.DataFrame(records)
df.to_csv("gpt_human_agreement_matrix.csv", index=False)
print("Saved to gpt_human_agreement_matrix.csv")
