import argparse
import base64
import json
import pathlib
import sys
import time

import pandas as pd
import requests
from tqdm import tqdm
from bs4 import BeautifulSoup

# LegiScan API base URL
LEGISCAN_API_URL = "https://api.legiscan.com/"

# Output directory for text files
TEXT_DIR = pathlib.Path("All Bills Text API")
TEXT_DIR.mkdir(parents=True, exist_ok=True)


def pick_doc(texts: list[dict],
             prefer_type: str | None = None,
             latest: bool = True) -> int | None:
    """
    Decide which `doc_id` to download.

    - `prefer_type`: e.g. "Enrolled", "Amended".  Case‑insensitive.
    - `latest=True`: choose the newest by `date` if the preferred
      type is not present.
    """
    if not texts:
        return None

    # (1) try an exact type match ------------------------------
    if prefer_type:
        for t in texts:
            if t.get("type", "").lower() == prefer_type.lower():
                return t["doc_id"]

    # (2) otherwise take the newest version --------------------
    if latest:
        newest = max(texts, key=lambda t: t.get("date") or "")
        return newest["doc_id"]

    # (3) finally, fall back to the first record ---------------
    return texts[0]["doc_id"]


def get_bill_doc_id(bill_id: int, api_key: str,
                    prefer_type: str | None = None) -> int | None:
    """Return a doc_id chosen by `pick_doc`."""
    params = {"key": api_key, "op": "getBill", "id": bill_id}
    try:
        rsp = requests.get(LEGISCAN_API_URL, params=params, timeout=30)
        rsp.raise_for_status()
        data = rsp.json()
    except Exception as e:
        print(f"[error] getBill failed for {bill_id}: {e}", file=sys.stderr)
        return None

    if data.get("status") != "OK":
        return None

    texts = data["bill"].get("texts", [])
    return pick_doc(texts, prefer_type=prefer_type)


# def get_bill_doc_id(bill_id: int, api_key: str) -> int | None:
#     """Fetches bill details from LegiScan API and returns the doc_id for the primary bill text."""
#     params = {
#         "key": api_key,
#         "op": "getBill",
#         "id": bill_id,
#     }
#     try:
#         response = requests.get(LEGISCAN_API_URL, params=params, timeout=30)
#         response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
#         data = response.json()

#         if data.get("status") == "OK" and "bill" in data and "texts" in data["bill"]:
#             # Find the primary bill text (often type_id 1 or the first one)
#             # You might need to adjust logic based on which version you need
#             texts = data["bill"]["texts"]
#             if texts:
#                 # Prioritize type_id 1 (usually 'Introduced', 'Draft', etc.)
#                 for text in texts:
#                     if text.get("type_id") == 1:
#                         return text.get("doc_id")
#                 # Fallback to the first text if type_id 1 not found
#                 return texts[0].get("doc_id")
#         else:
#             print(f"[warning] Bill ID {bill_id}: API status not OK or missing data. Status: {data.get('status')}", file=sys.stderr)
#             return None

#     except requests.exceptions.RequestException as e:
#         print(f"[error] Bill ID {bill_id}: Request failed for getBill: {e}", file=sys.stderr)
#     except json.JSONDecodeError:
#         print(f"[error] Bill ID {bill_id}: Failed to decode JSON response for getBill.", file=sys.stderr)
#     return None

import re
BLANKS = re.compile(r"[ \t]*\n([ \t]*\n)+")      # ≥2 consecutive blank lines

def _squeeze_blank_lines(txt: str, keep: int = 1) -> str:
    """Replace 2+ blank lines with exactly `keep` newlines (default = 1)."""
    repl = "\n" * keep
    return BLANKS.sub(repl, txt).strip()


def decode_bill_blob(encoded: str) -> tuple[str | bytes, str]:
    """
    Return (payload, ext).

    * If the blob is a PDF, payload is **bytes** and ext==".pdf".
    * Otherwise payload is **str** (plain text) and ext==".txt".
    """
    raw = base64.b64decode(encoded, validate=True)

    if raw[:5] == b"%PDF-":
        return raw, ".pdf"                       # binary
    # ↓ simple—but works because every HTML bill starts with "<pre>"
    if raw.lstrip().startswith(b"<"):
        soup = BeautifulSoup(raw, "lxml")
        text = soup.get_text("\n")
        text = _squeeze_blank_lines(text)        # see helper below
        return text, ".txt"

    # fallback: try utf‑8 decode
    return raw.decode("utf‑8", "replace"), ".txt"

def get_and_decode_bill_text(doc_id: int, api_key: str) -> str | None:
    """Fetches and decodes Base64 bill text from LegiScan API using doc_id."""
    params = {
        "key": api_key,
        "op": "getBillText",
        "id": doc_id,
    }
    try:
        response = requests.get(LEGISCAN_API_URL, params=params, timeout=60) # Longer timeout for potentially large text
        response.raise_for_status()
        data = response.json()

        if data.get("status") == "OK" and "text" in data and "doc" in data["text"]:
            encoded_doc = data["text"]["doc"]
            payload, ext = decode_bill_blob(encoded_doc)
            return payload, ext
            decoded_bytes = base64.b64decode(encoded_doc)
            # Attempt to decode as UTF-8, replace errors
            # plain_text = BeautifulSoup(decoded_bytes, "lxml").get_text("\n")
            # return plain_text
            return decoded_bytes.decode('utf-8', errors='replace')
        else:
            print(f"[warning] Doc ID {doc_id}: API status not OK or missing text data. Status: {data.get('status')}", file=sys.stderr)
            return None

    except requests.exceptions.RequestException as e:
        print(f"[error] Doc ID {doc_id}: Request failed for getBillText: {e}", file=sys.stderr)
    except json.JSONDecodeError:
        print(f"[error] Doc ID {doc_id}: Failed to decode JSON response for getBillText.", file=sys.stderr)
    except base64.binascii.Error as e:
         print(f"[error] Doc ID {doc_id}: Failed to decode Base64 text: {e}", file=sys.stderr)
    return None



def process_bills(df: pd.DataFrame, api_key: str) -> None:
    """Processes bills from DataFrame, fetches text via API, and saves to files."""
    if api_key == 'YOUR_API_KEY':
         sys.exit("Error: Please replace 'YOUR_API_KEY' with your actual LegiScan API key in the script.")

    required_columns = {"bill_id", "bill_number", "session_id"} # Assuming session_id might be useful for filename
    missing = required_columns - set(df.columns)
    if missing:
        sys.exit(f"Input Excel missing required columns: {', '.join(missing)}")

    for _, row in tqdm(df.iterrows(), total=len(df), desc="Processing Bills via API"):
        bill_id = row["bill_id"]
        bill_num = row["bill_number"]
        # Extract year from session_id or another column if available - adapt as needed
        # Example: Assume session_id corresponds to the start year of the session
        session_id = row["session_id"] # You might need a mapping or logic here if session_id isn't the year
        year_str = str(session_id) # Placeholder - adjust how you get the year

        if not isinstance(bill_id, (int, float)) or pd.isna(bill_id):
            print(f"[warning] Skipping row due to invalid Bill ID: {bill_id}", file=sys.stderr)
            continue
        bill_id = int(bill_id)

        # Respect crawl delay (Implicitly handled by sequential processing, but add explicit delay if needed)
        # time.sleep(2) # Uncomment if hitting rate limits despite sequential calls

        # doc_id = get_bill_doc_id(bill_id, api_key)
        doc_id = get_bill_doc_id(bill_id, api_key, prefer_type="enrolled")

        if doc_id:
            # Add another small delay before the next API call if needed
            # time.sleep(2)
            # decoded_text = get_and_decode_bill_text(doc_id, api_key)
            payload, ext = get_and_decode_bill_text(doc_id, api_key)
            txt_filename = f"{bill_num}_{year_str}{ext}"
            with open(TEXT_DIR / txt_filename,
                    "wb" if isinstance(payload, bytes) else "w",
                    encoding=None if isinstance(payload, bytes) else "utf-8") as fh:
                fh.write(payload)
            # if decoded_text:
            #     # Construct filename (e.g., BILLNUM_YEAR.txt)
            #     # Adapt year extraction if needed
            #     txt_filename = f"{bill_num}_{year_str}.txt"
            #     txt_path = TEXT_DIR / txt_filename
            #     try:
            #         with open(txt_path, "w", encoding="utf-8") as f:
            #             f.write(decoded_text)
            #     except IOError as e:
            #         print(f"[error] Failed to write file {txt_path}: {e}", file=sys.stderr)
            # else:
            #     print(f"[warning] Bill ID {bill_id}: Could not retrieve/decode text for Doc ID {doc_id}", file=sys.stderr)
        else:
             print(f"[warning] Bill ID {bill_id}: Could not find Doc ID.", file=sys.stderr)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Fetch bill texts using the LegiScan API.")
    parser.add_argument("--xlsx", default="random 1-50 policies - ian classify.xlsx", help="Source Excel file with bill IDs.")
    parser.add_argument("--sheet", default="all", help="Sheet name/idx inside the workbook.")
    parser.add_argument("--key", default="f3c43198c9a56646b602dcae42b9f669", help="Your LegiScan API Key.")
    # Add optional arguments for output dir, etc. if needed
    args = parser.parse_args(argv)

    try:
        df = pd.read_excel(args.xlsx, sheet_name=args.sheet, engine="openpyxl")
    except FileNotFoundError:
        sys.exit(f"Error: Input Excel file not found: {args.xlsx}")
    except Exception as e:
        sys.exit(f"Error reading Excel file: {e}")

    process_bills(df, args.key)
    print(f"\nProcessing complete. Text files saved to: {TEXT_DIR.resolve()}")


if __name__ == "__main__":
    main()
