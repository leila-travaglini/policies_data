# scrape_bills.py
"""
Batch‑scrape U.S. state energy & environment bills, download their PDF texts, strip any text
rendered with strike‑through annotations, and append the clean text to an aggregate Excel file.

Inputs
------
* energ_env_bills.xlsx            – may contain repeated bill/year pairs
* energ_env_bills_uniq.xlsx       – one row per unique bill/year

Outputs
-------
* ./All Policies/<bill_number>_<year>.pdf       – downloaded source document
* All Bills Text.xlsx                            – Excel workbook with two columns:
                                                 BillNumber | CleanText

How it works
------------
1.  Reads `energ_env_bills_uniq.xlsx` via **pandas**.
2.  For every row it
    * downloads the PDF (if not already present) into *All Policies*.
    * opens the PDF with **PyMuPDF** (a.k.a. *fitz*) and gathers rectangles of all
      *StrikeOut* annotations on every page.
    * parses the page layout to individual spans (`get_text("dict")`).
      Any span whose bounding box intersects a *StrikeOut* rectangle is skipped.
    * concatenates the remaining spans into a clean, page‑ordered string.
3.  Appends a new row to *All Bills Text.xlsx*; creates the workbook if it
    doesn't yet exist.

Install deps (Python ≥ 3.9):
>>> pip install pandas openpyxl requests tqdm pymupdf

Run:
>>> python scrape_bills.py  # uses defaults shown below

You can override paths with command‑line flags – see `main()`.
"""

from __future__ import annotations

import argparse
import pathlib
import sys
from typing import Iterable, List

import fitz  # PyMuPDF
import pandas as pd
import requests
from openpyxl import Workbook, load_workbook
from tqdm import tqdm
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import re, io

###############################################################################
# --------------------------- helper functions ------------------------------ #
###############################################################################

PDF_DIR = pathlib.Path("All Policies")
PDF_DIR.mkdir(parents=True, exist_ok=True)
EXCEL_OUT = pathlib.Path("All Bills Text.xlsx")


def download_pdf(url: str, dest_path: pathlib.Path, *, timeout: int = 30) -> None:
    """Stream a PDF from *url* into *dest_path* unless it already exists."""
    if dest_path.exists():
        return

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
    }
    r = requests.get(url, stream=True, timeout=timeout, headers=headers)
    r.raise_for_status()

    content_type = r.headers.get("Content-Type", "")
    pdf_url = None

    if "application/pdf" in content_type:
        # Direct PDF link, proceed to download
        pass
    elif "html" in content_type: # It's an HTML page, try to find the PDF link
        soup = BeautifulSoup(io.BytesIO(r.content), "html.parser")
        parsed_url = urlparse(url)

        # Site-specific selectors
        if "legis.iowa.gov" in parsed_url.netloc:
            # Iowa: Prioritize PDF links with keywords like "Introduced", "Filed", etc.
            # Fallback to links under /docs/publications/LGI/ if no keyworded link is found.
            preferred_link_tag = None  # For links with keywords
            fallback_lgi_link_tag = None # For LGI links

            for a in soup.find_all('a', href=True): # Using 'a' to match original style
                href = a.get('href', '')
                text = a.get_text()

                # Check for preferred type (keywords)
                if href.endswith('.pdf') and any(keyword in text for keyword in ["Introduced", "Filed", "Enrolled", "Published"]):
                    preferred_link_tag = a
                    break # Found the best possible link (keyworded), stop searching further.
                
                # If a preferred link hasn't been found *yet in the entire loop*
                # and if we haven't *already captured a fallback LGI link*,
                # then check if this is an LGI link.
                # This ensures we take the *first* LGI link encountered as a fallback,
                # and only if no preferred link has been found yet.
                if not preferred_link_tag and not fallback_lgi_link_tag:
                    if href.endswith('.pdf') and '/docs/publications/LGI/' in href:
                        fallback_lgi_link_tag = a
                        # No break, continue for potential preferred link.
            
            # pdf_url was initialized to None before this site-specific block.
            if preferred_link_tag:
                pdf_url = urljoin(url, preferred_link_tag['href'])
            elif fallback_lgi_link_tag:
                pdf_url = urljoin(url, fallback_lgi_link_tag['href'])
            # If neither specific Iowa link is found, pdf_url remains None,
            # allowing the generic fallback logic to attempt to find a PDF.

        elif "docs.legis.wisconsin.gov" in parsed_url.netloc:
            # Wisconsin: Look for links containing /document/bills/ and ending .pdf
            # or specifically labeled "PDF"
            found_link_tag = None # Renamed from found_link to avoid confusion
            link_patterns = [
                lambda a: a.get('href', '').endswith('.pdf') and '/document/bills/' in a.get('href', ''),
                lambda a: a.get_text(strip=True).upper() == "PDF" and a.get('href', '').endswith('.pdf')
            ]
            for pattern in link_patterns:
                found_link_tag = soup.find('a', pattern)
                if found_link_tag: # Check if found before breaking
                    pdf_url = urljoin(url, found_link_tag['href'])
                    break # Exit loop once found

        elif "coolice.legis.iowa.gov" in parsed_url.netloc:
            # Older Iowa site (coolice): Simple strategy - find first .pdf link
            for a in soup.find_all("a", href=True):
                href = a.get("href", "") # Use .get for safety
                if href.lower().endswith(".pdf"):
                    pdf_url = urljoin(url, href)
                    break

        # Generic fallback: find the first absolute link ending in .pdf
        if not pdf_url:
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if href.lower().endswith(".pdf"):
                    pdf_url = urljoin(url, href)
                    break

        if not pdf_url:
            raise ValueError(f"Could not find a PDF link on HTML page: {url}")

        # Fetch the found PDF URL
        r = requests.get(pdf_url, stream=True, timeout=timeout, headers=headers)
        r.raise_for_status()
        if "application/pdf" not in r.headers.get("Content-Type", ""):
            raise ValueError(f"Resolved link {pdf_url} did not return a PDF from {url}")

    else: # Neither PDF nor HTML, raise error
        raise ValueError(f"URL did not return a PDF or HTML page: {url} (Content-Type: {content_type})")

    # Now, download the content from the potentially updated request 'r'
    with dest_path.open("wb") as fh:
        for chunk in r.iter_content(chunk_size=8192):
            fh.write(chunk)


def _strike_rects(page: fitz.Page) -> List[fitz.Rect]:
    """Return rectangles covering all StrikeOut annotations on *page*."""
    rects: List[fitz.Rect] = []
    for annot in page.annots() or []:  # page.annots() may return None
        if annot.type[0] == fitz.PDF_ANNOT_STRIKEOUT:
            rects.append(annot.rect)
    return rects


def _span_is_struck(span_bbox: List[float], strike_rects: List[fitz.Rect]) -> bool:
    """True if span bounding‑box overlaps any strike‑out rectangle > 20  % area."""
    span_rect = fitz.Rect(span_bbox)
    for sr in strike_rects:
        inter = span_rect & sr
        if inter and inter.get_area() / span_rect.get_area() > 0.2:
            return True
    return False


def extract_clean_text(pdf_path: pathlib.Path) -> str:
    """Return text of *pdf_path* omitting spans flagged by strike‑through."""
    doc = fitz.open(pdf_path)
    pages_text: List[str] = []
    for page in doc:
        strike_rects = _strike_rects(page)
        page_dict = page.get_text("dict")
        kept_spans: List[str] = []
        for block in page_dict.get("blocks", []):
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    if not _span_is_struck(span["bbox"], strike_rects):
                        kept_spans.append(span["text"])
        pages_text.append(" ".join(kept_spans))
    return "\n\n".join(pages_text)


def append_to_excel(bill_number: str, clean_text: str, excel_path: pathlib.Path) -> None:
    """Append *(bill_number, clean_text)* as a new row in *excel_path*."""
    if excel_path.exists():
        wb = load_workbook(excel_path)
        ws = wb.active
    else:
        wb = Workbook()
        ws = wb.active
        ws.append(["BillNumber", "CleanText"])
    ws.append([bill_number, clean_text])
    wb.save(excel_path)

###############################################################################
# ----------------------------- main routine -------------------------------- #
###############################################################################

def process_records(df: pd.DataFrame, url_col: str = "state_link") -> None:
    for _idx, row in tqdm(df.iterrows(), total=len(df), desc="Bills"):
        bill_num: str = row["bill_number"]
        year: str | int = row["section_year"]
        url: str = row[url_col]
        print(url)
        pdf_filename = f"{bill_num}_{year}.pdf"
        pdf_path = PDF_DIR / pdf_filename

        try:
            download_pdf(url, pdf_path)
            text = extract_clean_text(pdf_path)
            append_to_excel(f"{bill_num}_{year}", text, EXCEL_OUT)
        except Exception as exc:
            print(f"[warning] {bill_num}_{year}: {exc}", file=sys.stderr)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Scrape energy/environment bills PDF text.")
    parser.add_argument("--xlsx", default="random 1-50 policies - ian classify.xlsx", help="Source Excel file with unique bills.")
    parser.add_argument("--sheet", default="all", help="Sheet name/idx inside the workbook.")
    parser.add_argument("--url_col", default="state_link", help="Column containing direct PDF URLs.")
    args = parser.parse_args(argv)

    df = pd.read_excel(args.xlsx, sheet_name=args.sheet, engine="openpyxl")
    required = {"bill_number", "section_year", args.url_col}
    missing = required - set(df.columns)
    if missing:
        sys.exit(f"Input Excel missing columns: {', '.join(missing)}")

    process_records(df, url_col=args.url_col)


if __name__ == "__main__":
    main()
